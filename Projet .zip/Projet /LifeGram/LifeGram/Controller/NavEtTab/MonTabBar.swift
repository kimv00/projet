//
//  MonTabBar.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class MonTabBar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBar.backgroundColor = .white
        tabBar.tintColor = .red
        
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        
        let fil = FilController(collectionViewLayout: layout)
        let notif = NotificationController(style: .plain)
        let profil = ProfilController(collectionViewLayout: layout)
        
        viewControllers = [
        ajouter(controller: fil, image: #imageLiteral(resourceName: "tab_accueil"), titre: "acceuil"),
        ajouter(controller: RechercheController(), image: #imageLiteral(resourceName: "Search"), titre: "Recherche"),
        ajouter(controller: PhotoController(), image: #imageLiteral(resourceName: "tab_photo"), titre: ""),
        ajouter(controller: notif, image: #imageLiteral(resourceName: "tab_notif"), titre: "Notification"),
        ajouter(controller: profil, image: #imageLiteral(resourceName: "profil"), titre: "profil")
        ]
        
    }

    func ajouter(controller: UIViewController, image: UIImage, titre: String) -> UINavigationController {
        let nav = MonNav(rootViewController: controller)
        nav.tabBarItem.image = image
        nav.tabBarItem.title = titre
        return nav
    }
}
