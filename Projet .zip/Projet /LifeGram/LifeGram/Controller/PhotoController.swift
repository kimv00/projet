//
//  PhotoController.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class PhotoController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var segment: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        let appareilNib = UINib(nibName: CAMERA_CELL, bundle: nil)
        let librairieNib = UINib(nibName: LIBRAIRIE_CELL, bundle: nil)
        collectionView.register(appareilNib, forCellWithReuseIdentifier: CAMERA_CELL)
        collectionView.register(librairieNib, forCellWithReuseIdentifier: LIBRAIRIE_CELL)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return segment.numberOfSegments
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if segment.selectedSegmentIndex == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CAMERA_CELL, for: indexPath) as!
            AppareilPhotoCell
            cell.miseEnPlaceAppareil(controller: self)
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LIBRAIRIE_CELL, for: indexPath) as!
            LibrairieCell
            cell.miseEnPlace(controller: self)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width, height: collectionView.frame.height)
    }
    
    func prendrePhotoEtSuivant(image: UIImage) {
        let controller = EffetController()
        controller.image = image
        navigationController?.pushViewController(controller, animated: true)
   }
    
    @IBAction func segmentChoisi(_ sender: Any) {
        let indexPath = IndexPath(item: segment.selectedSegmentIndex, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .right, animated: true)
    }
    

}
