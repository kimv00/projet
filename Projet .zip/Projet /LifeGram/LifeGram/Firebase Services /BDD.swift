//
//  BDD.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import Foundation
import FirebaseDatabase
import FirebaseAuth

class BDD {
    
    func recupererUtilisateur(id: String, completion: UtilisateurCompletion?) {
        Ref().utilisateurSpecifique(id: id).observe(.value) {(snapshot) in
            if snapshot.exists(), let _ = snapshot.value as? [String: AnyObject] {
                completion?(Utlisateur(snapshot: snapshot))
            } else {
                completion?(nil)
            }
        }
    }
    
    func usernameExiste(username: String, completion: SuccessCompletion?) {
        Ref().racineUtilisateur.queryOrdered(byChild: "username").queryEqual(toValue:
            username).observeSingleEvent(of: .value) { (snapshot) in
            if !snapshot.exists() {
                completion?(true, "")
            } else {
                completion?(false, "Nom d'utilisateur deja pris")
            }
        }
    }
    
    func miseAjourUtilisateur(dict: [String: AnyObject], completion: UtilisateurCompletion?) {
        guard let id = Auth.auth().currentUser?.uid else { completion?(nil); return }
        Ref().utilisateurSpecifique(id: id).updateChildValues(dict) {(error, ref) in
            if error == nil {
                self.recupererUtilisateur(id: id, completion: { (utilisateur) -> (Void) in
                    completion?(utilisateur)
                })
            }
        }
    }
}
