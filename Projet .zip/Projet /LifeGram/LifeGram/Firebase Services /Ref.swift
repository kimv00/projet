//
//  Ref.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import Foundation
import FirebaseDatabase
import FirebaseStorage

class Ref {
    
    let bdd = Database.database().reference()
    let stockage = Storage.storage().reference()
    
    var racineUtilisateur: DatabaseReference { return bdd.child("utilisateur")}
    
    func utilisateurSpecifique(id: String) -> DatabaseReference {
        return racineUtilisateur.child(id)
    }
}
