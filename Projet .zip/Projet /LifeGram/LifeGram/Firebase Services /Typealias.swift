//
//  Typealias.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

typealias UtilisateurCompletion = (_ utilisateur: Utlisateur?) -> (Void)
typealias SuccessCompletion = (_ success: Bool?, _ erreur: String?) -> (Void)
