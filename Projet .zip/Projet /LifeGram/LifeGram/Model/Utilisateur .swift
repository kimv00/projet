//
//  Utilisateur .swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit
import FirebaseDatabase

class Utlisateur  {
    
    private var _ref: DatabaseReference!
    private var _id: String!
    private var _username: String!
    private var _prenom: String!
    private var _nom: String!
    private var _desc: String!
    private var _imageUrl: String!
    private var _abonnes: [String]!
    private var _abonnements: [String]!
    
    var ref: DatabaseReference { return _ref }
    var id : String { return _id }
    var username : String { return _username }
    var nom : String { return _nom }
    var prenom : String { return _prenom }
    var desc : String { return _desc }
    var imageUrl : String { return _imageUrl }
    var abonnes : [String] { return _abonnes }
    var abonnements : [String] { return _abonnements }
    
    init(snapshot: DataSnapshot) {
        guard let dict = snapshot.value as? [String: AnyObject] else { return }
        self._ref = snapshot.ref
        self._id = snapshot.key
        self._username = dict["username"] as? String ?? ""
        self._prenom = dict["prenom"] as? String ?? ""
        self._nom = dict["nom"] as? String ?? ""
        self._desc  = dict["desc"] as? String ?? ""
        self._imageUrl = dict["imageUrl"] as? String ?? ""
        self._abonnes = dict["abonnes"] as? [String] ?? []
        self._abonnements = dict["abonnements"] as? [String] ?? []
    }
    
}
