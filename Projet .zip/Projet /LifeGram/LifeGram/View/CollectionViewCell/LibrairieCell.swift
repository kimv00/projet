//
//  LibrairieCell.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit
import Photos

let LIBRAIRIE_CELL = "LibrairieCell"

class LibrairieCell: UICollectionViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var imageView: UIImageView!
    
    var controller : PhotoController?
    
    var images = [UIImage]()
    var assets = [PHAsset]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func miseEnPlace(controller: PhotoController) {
        self.controller = controller
        collectionView.delegate = self
        collectionView.dataSource = self
        let nib = UINib(nibName: IMAGE_CARRE_CELL, bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: IMAGE_CARRE_CELL)
        recuperPhotos()
        let statut = PHPhotoLibrary.authorizationStatus()
        if statut == .notDetermined {
            PHPhotoLibrary.requestAuthorization({ (statut) in
                if statut == .authorized {
                    self.recuperPhotos()
                }
            })
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: IMAGE_CARRE_CELL, for: indexPath) as! ImageCarreCell
        cell.imageView.image = images [indexPath.row]
        return cell
    }
    
    func fecthOptions() -> PHFetchOptions {
        let fetchOption = PHFetchOptions()
        fetchOption.fetchLimit = 50
        let trieur = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchOption.sortDescriptors = [trieur]
        return fetchOption
    }
    
    func recuperPhotos() {
        let tousMesAssets = PHAsset.fetchAssets(with: .image, options: fecthOptions())
        DispatchQueue.global(qos: .background).async {
            tousMesAssets.enumerateObjects({ (asset, count, stop) in
                let imageManager = PHImageManager.default()
                let taille = CGSize(width: 200, height: 200)
                let options = PHImageRequestOptions()
                options.isSynchronous = true
                imageManager.requestImage(for: asset, targetSize: taille, contentMode: .aspectFit, options: options, resultHandler: {(image, info) in
                    if let monImage = image {
                        self.images.append(monImage)
                        self.assets.append(asset)
                    }
                    
                    if count == tousMesAssets.count - 1 {
                        DispatchQueue.main.async {
                            self.collectionView.reloadData()
                        }
                    }
                })
            })
        }
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
