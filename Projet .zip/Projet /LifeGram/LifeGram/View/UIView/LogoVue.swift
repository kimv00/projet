//
//  LogoVue.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class LogoVue: UIView {
    
    var logoImageVue: UIImageView!

    override init(frame: CGRect) {
        super.init(frame: frame)
        miseEnplace()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        miseEnplace()
    }
    
    func miseEnplace() {
        logoImageVue = UIImageView(frame: CGRect(x: 20, y: 0, width: frame.width - 40, height: frame.height))
        logoImageVue.image = #imageLiteral(resourceName: "logo")
        logoImageVue.contentMode = .scaleAspectFit
        logoImageVue.clipsToBounds = true
        addSubview(logoImageVue)
        
    }

}
