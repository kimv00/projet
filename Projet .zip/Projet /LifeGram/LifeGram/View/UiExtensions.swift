//
//  UiExtensions.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

extension UIViewController {
    
    func clavier() {
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(cacherClavier)))
    }
    
    @objc func cacherClavier() {
        self.view.endEditing(true)
    }
}

extension UIView {
    
    func chargerXib() -> UIView {
        let bundle = Bundle(for: type(of: self))
        let nomXib = type(of: self).description().components(separatedBy: ".").last!
        let nib = UINib(nibName: nomXib, bundle: bundle)
        let vue = nib.instantiate(withOwner: self, options: nil).first as! UIView
        vue.frame = bounds
        addSubview(vue)
        vue.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        backgroundColor = .white
        return vue
    }
}
